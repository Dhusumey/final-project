# Flutter Food Recipes Cookpad App

A new Flutter Food Recipes Cookpadapplication. Designed by Hijin Nam, Code using Flutter by Abdul Aziz Ahwan

# Food Recipes CookpadApp UI Design - Flutter UI Best Practice

[![Donate with PayPal](https://raw.githubusercontent.com/aha999/DonateButtons/master/Paypal.png)](https://paypal.me/abdulazizahwan)

## Watch it on YouTube

- Here => [Watch it on YouTube](https://youtu.be/0Ix47xWH6ac)

**Project Contents**

- (starter & final)

**⚠️ Instruction**

- For the very first, run `flutter pub get` on your favorite IDE

**Packages we are using:**

- flutter_svg: [get package](https://pub.dev/packages/flutter_svg)

**Fonts**

- SF Pro Text

**UI Credit**

- UI Design Credit by Hijin Nam check out on [see the profile](https://sketchrepo.com/free-sketch/food-app-concept-freebie/)

**Code Credit**

- Code using Flutter with ❤️ by [Abdul Aziz Ahwan](https://youtube.com/abdulazizahwanID)

### Food Recipes CookpadApp Final UI

[![Food Recipes CookpadApp UI Design](/img-ui.png)](https://sketchrepo.com/free-sketch/food-app-concept-freebie/)
